/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto.individual.sprint.um;

import java.util.Scanner;

/**
 *
 * @author dusda
 */
public class Projeto {

    public static void main(String[] args) {

        Integer voto;
        Integer idade;

        Scanner dados = new Scanner(System.in);

        System.out.println("Oi! Bem vindo(a)a votação do MNET o maior concurso de kpop!, qual o seu nome?");
        String nome = dados.nextLine();

        System.out.println("Seja bem vindo(a)," + nome);

        System.out.println("Agora digite sua idade:");
        idade = dados.nextInt();
        
        Scanner quizDebutScan = new Scanner(System.in);
        Scanner quizHitScan = new Scanner(System.in);
        Scanner quizIdadeScan = new Scanner(System.in);
        
        Scanner musicaFav = new Scanner(System.in);
        
        Scanner jogoDeNovo = new Scanner(System.in);

        if (idade < 18) {
            System.out.println("Você não tem idade suficiente! Espere mais " + (18 - idade) + " anos para votar!");
        } else {
            System.out.println("Nos informe o grupo que mais se destacou esse ano!\n"
                    + "ATEEZ - 1\n"
                    + "NCT - 2\n"
                    + "BTS - 3\n"
                    + "Sair da votação - 4\n"
                    + "Quiz BTS - 5");
            voto = dados.nextInt();
            Integer votoAteez = 0;
            Integer votoBts = 0;
            Integer votoNct127 = 0;
            Integer votoNctU = 0;
            Integer votoNctDream = 0;
            Integer votoWayV = 0;

            if (voto > 5) {
                System.out.println("opcão inválida!!!!");
            } else {

                switch (voto) {

                    case 1:
                        System.out.println("Você votou em ATEEZ! Obrigado por votar!");
                        votoAteez++;
                        break;

                    case 2:
                        System.out.println("Você votou em NCT! Qual subUnit?");
                        Scanner subUnit = new Scanner(System.in);
                        String subUnitVoto = subUnit.nextLine();
                        
                        System.out.println("As opções são:\n"
                                + "NCT 127\n"
                                + "NCT U\n"
                                + "NCT Dream\n"
                                + "Way V");

                        if (subUnitVoto.equals("NCT 127")) {
                            System.out.println("Você votou na subUnit Nct 127! Obrigado por votar!");
                            votoNct127++;
                            break;
                        } else if (subUnitVoto.equals("NCT U")) {
                            System.out.println("Você votou na subUnit Nct U! Obrigado por votar!");
                            votoNctU++;
                            break;

                        } else if (subUnitVoto.equals("NCT Dream")) {
                            System.out.println("Você votou na subUnit Nct Dream! Obrigado por votar!");
                            votoNctDream++;
                            break;

                        } else {
                            System.out.println("Você votou na subUnit Way V! Obrigado por votar!");
                            votoWayV++;
                            break;
                        }
                        
                        

                    case 3:
                        System.out.println("Você votou em BTS! Obrigado por votar!");
                        votoBts++;
                        
                        
                        System.out.println("Qual sua música favorita?");
                        String musicaFavorita = musicaFav.nextLine();
                        
                        System.out.println("Sua música favorita é: "+musicaFavorita +"?\n Que legal eu gosto dela também!");
                        
                        
                        
                        
                        break;

                    case 4:
                        System.out.println("Até logo!");
                        
                    case 5:
                       
                        for(int i = 0; i<=10; i++){
                        System.out.println("Já que você gosta muito do BTS: aproveite esse mini quiz sobre o grupo!");
                        System.out.println("Em que ano o grupo Debutou?");
                        Integer quizDebut = quizDebutScan.nextInt();
                        Integer valorCorreto = 2013;
                        Integer erros = 0;
                        Integer acertos = 0;
                        if(!quizDebut.equals(valorCorreto)){
                            System.out.println("Ops, infelizmente você errou!");
                            erros++;
                        }else{
                            System.out.println("Parabéns, você acertou!");
                            acertos++;
                            
                        }
                        
                        System.out.println("Qual o maior hit do grupo?");
                        
                        String quizHit = quizHitScan.nextLine();
                        String valorCorretoHit = "Spring day";
                        if(!quizHit.equals(valorCorretoHit)){
                            System.out.println("Ops, infelizmente você errou!");
                            erros++;
                        }else{
                            System.out.println("Parabéns, você acertou!");
                            acertos++;
                        }
                        
                        System.out.println("qual a idade do membro Jungkook?");
                        
                        Integer quizIdade = quizIdadeScan.nextInt();
                        Integer valorCorretoIdade = 25;
                        
                        if(!quizIdade.equals(valorCorretoIdade)){
                            System.out.println("Ops, infelizmente você errou!");
                            erros++;
                        }else{
                            System.out.println("Parabéns, você acertou!");
                            acertos++;
                        }
                        
                        System.out.println(nome + ", Você acertou " + acertos + " questões, e errou "+erros);                 
                        break;
                }
                }
            }
        }

    }
}
